-- AlterTable
ALTER TABLE "StoreProduct" ADD COLUMN     "color_id" INTEGER;
